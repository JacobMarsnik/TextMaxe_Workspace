package model;

import characters.PlayerCharacter;
import model.Chest;
import model.Key;
import model.Wall;

public class GameBoard {

	PlayerCharacter player = new PlayerCharacter("Donovan", 50, 10, 5);
	Object newObject = new Object("Object");

	private String move;
	int inputNum = 0;
	private int temp;
	private int interactionNum;
	private int SPX = 1;
	private int SPY = 1;
	private int playerID = 99;
	private int eventNumber;
	private int PPX;
	private int PPY;
	private String output;
	private String action;
	private String[] info = new String[2];
	private boolean found;
	Chest chest = new Chest("Chest");
	Wall wall = new Wall("Wall");
	Ground ground = new Ground("Ground");
	Key key = new Key("Key");
	GoldenKey GKey = new GoldenKey("Golden Key");
	

	int[][] mazeArray = new int[][]

	{ { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, { 1, 0, 9, 2, 0, 3, 0, 1, 0, 0, 8, 1 },
			{ 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 }, { 1, 0, 2, 0, 6, 0, 0, 1, 7, 0, 0, 1 },
			{ 1, 4, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 }, { 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
			{ 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 9, 1 }, { 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
			{ 1, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 1 }, { 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 9, 1 },
			{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };

	public void startMaze() {
		eventNumber = mazeArray[SPX][SPY]; // set the original event number to the starting spots value
		mazeArray[SPX][SPY] = playerID; // set the player to beginning spot
		PPX = SPX;
		PPY = SPY;

	}

	public String[] moveLeft() {
		temp = eventNumber;
		found = false;
		String showInfo = "Nothing";
		for (int i = 0; found == false && i < mazeArray.length; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i][j - 1];
//					showInfo = checkSpotValue(eventNumber);
					info = checkSpotValue(eventNumber);
					if (eventNumber == 1) {
						eventNumber = temp;
						return info;

					} else {
						mazeArray[i][j] = temp;
						mazeArray[i][j - 1] = playerID;
						found = true;
					}
				}
			}
		}
		return info;
	}

	public String[] moveRight() {
		temp = eventNumber;
		found = false;
//		String showInfo = "Nothing";
//		String showAction = "No action";
		for (int i = 0; !found && i < mazeArray.length; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i][j + 1];
//					showInfo = checkSpotValue(eventNumber);
					info = checkSpotValue(eventNumber);
					if (eventNumber == 1) {
						eventNumber = temp;
						return info;
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i][j + 1] = playerID;
						found = true;

					}
				}
			}
		}
		return info;
	}

	public String[] moveDown() {
		temp = eventNumber;
		found = false;
		String showInfo = "Nothing";
		String showAction = "No action";

		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i + 1][j];
//					showInfo = checkSpotValue(eventNumber);
					info = checkSpotValue(eventNumber);
					if (eventNumber == 1) {
						eventNumber = temp;
						return info;
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i + 1][j] = playerID;
						found = true;

					}
				}
			}
		}
		return info;
	}

	public String[] moveUp() {
		temp = eventNumber;
		found = false;
		String showInfo = "Nothing";

		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i - 1][j];
//					showInfo = checkSpotValue(eventNumber);
					info = checkSpotValue(eventNumber);
					if (eventNumber == 1) {
						eventNumber = temp;
						return info;
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i - 1][j] = playerID;
						found = true;

					}
				}
			}
		}
		return info;
	}

	public String[] checkSpotValue(int x) {

		switch (x) {
		case 0:
			x = 0;
			
			
			
//			output = ground.Description();

			info[0] = ground.Description();
			info[1] = ground.Action();
			break;

		case 1:
			x = 1;

			
//			output = wall.Description();
			
			info[0] = wall.Description();
			info[1] = wall.Action();

			break;

		case 2:
			x = 2;
			
			info[0] = chest.Description();
			info[1] = chest.Action();
			newObject = chest;
//			output = chest.Description();
//			action = chest.Action();
			break;

		case 3:
			x = 3;
			break;

		case 4:
			x = 4;
			break;

		case 5:
			x = 5;
			break;
		case 6:
			x = 6;
			break;
		case 7:
			x = 7;
			break;
		case 8:
			x = 8;
			break;
		case 9:
			x = 9;
			
//			output = key.Description();
			newObject = key;
			info[0] = key.Description();
			info[1] = key.Action();
			break;
		}

		return info;

	}

public String doAction() {
	
	switch(newObject.getName()){
		case "Key": player.addToInventory(newObject);
		output = key.Loot();
		break;
		case "Chest": found = player.findKey();
			if(found) {
				output = chest.Loot();
				found = chest.haveGoldKey();
				if(found) {
					player.addToInventory(GKey);
					output = chest.Loot();
				}
				
			}
			else {
				output = "You cant open this chest, perhaps you are missing something.";
			}
	}
	return output;
		
		
	}

	public int getTemp() {
		return temp;
	}

	public void setTemp(int temp) {
		this.temp = temp;
	}

	public int getInteractionNum() {
		return interactionNum;
	}

	public void setInteractionNum(int interactionNum) {
		this.interactionNum = interactionNum;
	}

	public int getSPX() {
		return SPX;
	}

	public void setSPX(int sPX) {
		SPX = sPX;
	}

	public int getSPY() {
		return SPY;
	}

	public void setSPY(int sPY) {
		SPY = sPY;
	}

	public int getPlayerID() {
		return playerID;
	}

	public void setPlayerID(int playerID) {
		this.playerID = playerID;
	}

	public int getEventNumber() {
		return eventNumber;
	}

	public void setEventNumber(int eventNumber) {
		this.eventNumber = eventNumber;
	}

	public int getPPX() {
		return PPX;
	}

	public void setPPX(int pPX) {
		PPX = pPX;
	}

	public int getPPY() {
		return PPY;
	}

	public void setPPY(int pPY) {
		PPY = pPY;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}

	public boolean isFound() {
		return found;
	}

	public void setFound(boolean found) {
		this.found = found;
	}

	public PlayerCharacter getPlayer() {
		return player;
	}

	public void setPlayer(PlayerCharacter player) {
		this.player = player;
	}

	public String getMove() {
		return move;
	}

	public void setMove(String move) {
		this.move = move;
	}

	public int[][] getMazeArray() {
		return mazeArray;
	}

	public void setMazeArray(int[][] mazeArray) {
		this.mazeArray = mazeArray;
	}

	public void CheckInputNum() {
		// TODO Auto-generated method stub

	}

	

}
