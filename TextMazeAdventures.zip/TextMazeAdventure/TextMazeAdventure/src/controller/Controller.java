package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import model.GameBoard;
import view.GameView;

public class Controller {
	private GameBoard model;
	private int inputNum;
	private String[] showOutput = new String[2];
	private String action;

	GameView newView = new GameView();
	GameBoard newModel = new GameBoard();


	public Controller() {

		ActionListener listen = new EnterKeyHandler();

		newView.playerCommand().addActionListener(listen);

		newModel.startMaze();

		newView.updateTextArea("Welcome to the Maze ");
		newView.updateTextArea("Where would you like to move");
		

	}

	public void addModel(GameBoard m) {
		this.model = m;
	}

	

	public void checkInput() {
		
		String newInput = newView.playerCommand().getText();
		switch (inputNum) {
		case 0:
			move(newInput);
			break;
		case 1:
			ynFunction(newInput);
			break;

		default:
			newView.updateTextArea("Please enter a valid instruction" + "\n");
		}
	}

	

	private void move(String s) {

		switch (s.toLowerCase()) {
		case "right":
			showOutput =	newModel.moveRight();
	
			newView.updateTextArea(showOutput[0] + "\n");
			newView.updateTextArea(showOutput[1] + "\n");
			if(showOutput[1] != "" || !showOutput[1].isEmpty()) {
				newView.updateTextArea("There was an action");
				inputNum = 1;
			}
			
			break;
		case "left":
			showOutput =	newModel.moveLeft();
		
			newView.updateTextArea(showOutput[0] + "\n");
			newView.updateTextArea(showOutput[1] + "\n");
			if(showOutput[1] != "" || !showOutput[1].isEmpty()) {
				newView.updateTextArea("There was an action");
				inputNum = 1;
			}
	
			break;
		case "down":
			showOutput = newModel.moveDown();
			
			newView.updateTextArea(showOutput[0] + "\n");
			newView.updateTextArea(showOutput[1] + "\n");
			if(showOutput[1] != "" || !showOutput[1].isEmpty()) {
				newView.updateTextArea("There was an action");
				inputNum = 1;
			}
			
			break;
		case "up":
			showOutput = newModel.moveUp();
		
			newView.updateTextArea(showOutput[0] + "\n");
			newView.updateTextArea(showOutput[1] + "\n");
			if(showOutput[1] != "" || !showOutput[1].isEmpty()) {
				newView.updateTextArea("There was an action");
				inputNum = 1;
			}
			
			break;
		default: 
			newView.updateTextArea("Please Enter in a valid command" + "\n");
		}
		
		
	}
	
	public void askMove(){
		newView.updateTextArea("Where would you like to move" + "\n");
		
	}

	public int changeInputNum( int x) {
		
		 int newInput = x;
		return newInput;
		
	}
	
	public void ynFunction(String newInput) {
		// TODO Auto-generated method stub
		if(newInput.toLowerCase().equals("yes")) {
			newView.updateTextArea("Action Succesful");
		String actionOutput = newModel.doAction();
		newView.updateTextArea(actionOutput);
			inputNum   = 0;
		}
		else if(newInput.toLowerCase().equals("no")) {
			newView.updateTextArea("Action not Succesful");
			inputNum = 0;
		}
		else {
			newView.updateTextArea("Hmmm that dosnt seem right");
			
			
		}
		
		
	}
	
	
	
	private class EnterKeyHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			//newView.updateTextArea("\n" + "text");
			checkInput();
			newView.playerCommand().setText("");

		}

	}

}
