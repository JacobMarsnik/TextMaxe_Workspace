package view;

public class Viewable {

	
	
public void updateViewer() {
	
	
	
}

	
}
