package playerCharacter;

public class BaseCharacter {
	
	private String name;
	private int health;
	private int[] inventory;
	final private int size;
	private int attack;
	public BaseCharacter(String n, int h, int s, int a) {
		name = n;
		health = h;
		size = s;
		attack = a;
		inventory = new int[size];
		
	}

	
	public int changeHealth(int c) {
	int	newHealth = health - c;
	health = newHealth;
	return health;
	}


	public int getAttack() {
		return attack;
	}
	
	public void setAttack(int attack) {
		this.attack = attack;
	}
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getHealth() {
		return health;
	}


	public void setHealth(int health) {
		this.health = health;
	}


	public int[] getInventory() {
		return inventory;
	}


	public void setInventory(int[] inventory) {
		this.inventory = inventory;
	}


	public int getSize() {
		return size;
	}


	
	
	
}
