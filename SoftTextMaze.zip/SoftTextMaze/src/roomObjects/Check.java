package roomObjects;
//import movement.Move;
import textmaze.MainMaze;


public class Check  {
	private int interNumber;
	
	
//	Events event = new Events();


	public Check() {
		

	}

	public int checkSpotValue(int x) {

		switch (x) {
		case 0:
			x = 0;
//			event.Nothing();
			break;

		case 1:
			x = 1;
			
			Wall wall = new Wall("Wall");
			wall.Description();
			
			break;

		case 2:
			x = 2;
			Chest chest = new Chest("Chest");
			chest.Description();
			break;

		case 3:
			x = 3;
			break;

		case 4:
			x = 4;
			break;

		case 5:
			x = 5;
			break;
		case 6:
			x = 5;
			break;
		case 7:
			x = 5;
			break;
		case 8:
			x = 5;
			break;
		case 9:
			x = 5;
			break;
		}
		
		return x;

	}
	
	public int moveCheck(String x) {
		int k = 0;
		switch (x.toLowerCase()) {

		case "left":
			k = 1;
			
			break;

		case "right":
			k = 2;
			break;

		case "up":
			k = 3;
			break;

		case "down":
			k = 4;
			break;
			
		default:
			System.out.println("Please pick a valid direction");
			k = 0;

		}
		
		return k;
	}
	
	
		
}
