package roomObjects;
//import movement.Move;
import textmaze.MainMaze;

public class Check  {
	private int interNumber;


	public Check() {
		

	}

	public int checkSpotValue(int x) {

		switch (x) {
		case 0:
			x = 0;
			break;

		case 1:
			x = 1;
			System.out.println("You can't move here.");
			
			break;

		case 2:
			x = 2;
			break;

		case 3:
			x = 3;
			break;

		case 4:
			x = 4;
			break;

		case 5:
			x = 5;
			break;
		}
		
		return x;

	}
	
	public int moveCheck(String x) {
		int k = 0;
		switch (x) {

		case "Left":
			k = 1;
			
			break;

		case "Right":
			k = 2;
			break;

		case "Up":
			k = 3;
			break;

		case "Down":
			k = 4;
			break;

		}
		
		return k;
	}
	
	
		
}
