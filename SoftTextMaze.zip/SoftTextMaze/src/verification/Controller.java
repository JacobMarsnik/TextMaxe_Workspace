package verification;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import textmaze.MainMaze;

public class Controller implements ActionListener {

	private MainMaze main;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		main.getInput();
		
		
	}
	
	

}
