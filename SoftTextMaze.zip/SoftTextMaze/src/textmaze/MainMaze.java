package textmaze;

import roomObjects.Check;

import java.util.Arrays;
import java.util.Scanner;

//import movement.Move;
import playerCharacter.BaseCharacter;

public class MainMaze {
	private int temp;
	private int interactionNum;
	private int SPX = 1; 
	private int SPY = 1; 
	private int playerID = 99;
	private int eventNumber; 
	private int PPX;
	private int PPY;
	private boolean found;
	
	Check newCheck = new Check();	
	//Move newMove = new Move();	
	private String move;
	
	int[][] mazeArray = new int[][]

			{ { 1, 1, 1, 1 }, { 1, 0, 0, 1 }, { 1, 0, 0, 1 }, { 1, 1, 1, 1 } };
			Scanner input = new Scanner(System.in);
		
	public MainMaze() {
		

	}

	public void startMaze() {

		eventNumber = mazeArray[SPX][SPY]; // set the original event number to the starting spots value
		mazeArray[SPX][SPY] = playerID; // set the player to beginning spot
		PPX = SPX;
		PPY = SPY;
		askMove();
		
		//move = newMove.askMove();
		

	}

	public void displayGrid() {
		System.out.println(Arrays.deepToString(mazeArray));
	}
	public void moveLeft() {
		temp = eventNumber; 
		found = false;
		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) { 
				if (mazeArray[i][j] == playerID) { 
					eventNumber = mazeArray[i][j - 1]; 
					interactionNum = newCheck.checkSpotValue(eventNumber);
					if (interactionNum == 1) {
						askMove();
					} else {
						mazeArray[i][j] = temp; 
						mazeArray[i][j - 1] = playerID; 
						found = true;
						displayGrid();
					}
				}
			}
		}
	}

	public void moveRight() {
		temp = eventNumber;
		found = false;
		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i][j + 1];
					interactionNum = newCheck.checkSpotValue(eventNumber);
					if (interactionNum == 1) {
						askMove();
					} else {
					mazeArray[i][j] = temp;
					mazeArray[i][j + 1] = playerID;
					found = true;
					displayGrid();
				}
			}
			}
		}

	}

	public void moveDown() {
		temp = eventNumber;
		found = false;

		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i + 1][j];
					interactionNum = newCheck.checkSpotValue(eventNumber);
					if (interactionNum == 1) {
						askMove();
					} else {
					mazeArray[i][j] = temp;
					mazeArray[i + 1][j] = playerID;
					found = true;
					displayGrid();

				}
			}
			}
		}
	}

	public void moveUp() {
		temp = eventNumber;
		found = false;

		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i - 1][j];
					interactionNum = newCheck.checkSpotValue(eventNumber);
					if (interactionNum == 1) {
						askMove();
					} else {
					mazeArray[i][j] = temp;
					mazeArray[i - 1][j] = playerID;
					found = true;
					displayGrid();
				}
			}
			}
		}
	}

	public void askMove() {
		
		int moveNum;
		
		System.out.println("Where would you like to move next?");
		move = input.nextLine();
	moveNum =	newCheck.moveCheck(move);

	switch (moveNum) {

	case 1:
		moveLeft();
		
		break;

	case 2:
		moveRight();
		break;

	case 3:
		moveUp();
		break;

	case 4:
		moveDown();
		break;

	}
	
	
		
	}


	
	
}