package maze_app;

import textmaze.*;
import textmaze.MainMaze;
import view.GameView;


public class TestMazeRun  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub



		MainMaze newMaze = new MainMaze();
		newMaze.displayGrid();
		newMaze.startMaze();
		

	}

}
