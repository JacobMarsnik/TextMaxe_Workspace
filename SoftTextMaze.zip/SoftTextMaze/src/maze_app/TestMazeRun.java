package maze_app;

import textmaze.*;
import textmaze.MainMaze;

public class TestMazeRun  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MainMaze newMaze = new MainMaze();
		newMaze.displayGrid();
		newMaze.startMaze();
		

	}

}
