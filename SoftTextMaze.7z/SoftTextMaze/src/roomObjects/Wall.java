package roomObjects;

public class Wall extends Object implements StandardObject {

	public Wall(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {
		String desc = "A wall covered in dust and moss, these walls have stood the test of time.";
		return desc;
	}

	@Override
	public void Action() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Loot() {
		// TODO Auto-generated method stub
		
	}

}
