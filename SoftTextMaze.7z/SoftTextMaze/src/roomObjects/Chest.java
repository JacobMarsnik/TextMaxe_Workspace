package roomObjects;

import java.util.Scanner;

public class Chest extends Object implements StandardObject {

	String desc;
	boolean open = false;
	

	public Chest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {

		desc = "Before you sits an aincent wooden chest. The lock seems to be rusted, you might be able to open it and see what is inside";

		Action();

		return desc;
	}

	@Override
	public void Action() {

		String awnser;
		System.out.println("Do you want to open the chest?");

		awnser = input.nextLine();

		if (awnser.toLowerCase().equals("yes")) {
			Loot();
		}
		// Redirect back to ask move

	}

	@Override
	public void Loot() {
		// TODO Auto-generated method stub
		System.out.println("It seems to be empty, an unfortunate turn of events.");

	}

}
