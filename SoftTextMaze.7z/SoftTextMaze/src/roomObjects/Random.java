package roomObjects;
import java.util.concurrent.ThreadLocalRandom;

public class Random {
	private int min = 0;
	private int max = 10;
	
	public Random() {
		
	}
	
	public int getRandom() {
		int randomNumber = ThreadLocalRandom.current().nextInt(min, max +1);
		return randomNumber;
		
	}

}
