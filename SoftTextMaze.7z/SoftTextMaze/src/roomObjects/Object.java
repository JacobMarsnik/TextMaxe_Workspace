package roomObjects;

import java.util.Scanner;

public class Object  {
	Random rand = new Random();
	Scanner input = new Scanner(System.in);
	private String name;
	private String loot;
	
	public  Object( String name) {
		this.name = name;
		
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	

}
