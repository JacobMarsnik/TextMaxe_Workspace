package playerCharacter;

import java.util.ArrayList;
import java.util.List;

public class BaseCharacter {

	private String name;
	private int health;

	final private int size;
	private int attack;
	
	List<Object> inventory = new ArrayList<Object>();
	public BaseCharacter(String n, int h, int s, int a) {
		name = n;
		health = h;
		size = s;
		attack = a;
		
		

	}

	public int changeHealth(int c) {
		int newHealth = health - c;
		health = newHealth;
		return health;
	}

	public void addToInventory(Object newObject) {

		inventory.add(newObject);
		
		
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	

	public List<Object> getInventory() {
		return inventory;
	}

	public void setInventory(List<Object> inventory) {
		this.inventory = inventory;
	}

	public int getSize() {
		return size;
	}

}
