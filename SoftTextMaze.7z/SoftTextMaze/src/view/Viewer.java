package view;

public interface Viewer {

	
	public void update();
}
