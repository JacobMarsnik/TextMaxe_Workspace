package textmaze;

import roomObjects.Check;

import java.util.Arrays;
import java.util.Scanner;

//import movement.Move;
import playerCharacter.BaseCharacter;

import view.GameView;
import view.Viewable;

public class MainMaze extends Viewable {
	private int temp;
	private int interactionNum;
	private int SPX = 1;
	private int SPY = 1;
	private int playerID = 99;
	private int eventNumber;
	private int PPX;
	private int PPY;
	private boolean found;
	GameView newView = new GameView();
	Check newCheck = new Check();
	BaseCharacter player = new BaseCharacter("Donovan", 50, 10, 5);
	// Move newMove = new Move();
	private String move;

	int[][] mazeArray = new int[][]

	{ { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, { 1, 0, 2, 0, 0, 3, 0, 1, 0, 0, 8, 1 },
			{ 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 }, { 1, 0, 2, 0, 6, 0, 0, 1, 7, 0, 0, 1 },
			{ 1, 4, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 }, { 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
			{ 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 9, 1 }, { 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
			{ 1, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 1 }, { 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 9, 1 },
			{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };

	Scanner input = new Scanner(System.in);

	public MainMaze() {

	}

	public void startMaze() {

		eventNumber = mazeArray[SPX][SPY]; // set the original event number to the starting spots value
		mazeArray[SPX][SPY] = playerID; // set the player to beginning spot
		PPX = SPX;
		PPY = SPY;
		String line = "Where would you like to move next?";
		newView.updateTextArea(line);
		

		// move = newMove.askMove();

	}

	public void displayGrid() {
		System.out.println(Arrays.deepToString(mazeArray));
	}

	public void moveLeft() {
		temp = eventNumber;
		found = false;
		for (int i = 0; found == false && i < mazeArray.length; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i][j - 1];
					interactionNum = newCheck.checkSpotValue(eventNumber);
					if (interactionNum == 1) {
						eventNumber = temp;
						displayGrid();
						askMove();
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i][j - 1] = playerID;
						found = true;
						displayGrid();
						askMove();
					}
				}
			}
		}
	}

	public void moveRight() {
		temp = eventNumber;
		found = false;
		for (int i = 0; !found && i < mazeArray.length; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i][j + 1];
					interactionNum = newCheck.checkSpotValue(eventNumber);
					if (interactionNum == 1) {
						eventNumber = temp;
						displayGrid();
						askMove();
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i][j + 1] = playerID;
						found = true;
						displayGrid();
						askMove();
					}
				}
			}
		}

	}

	public void moveDown() {
		temp = eventNumber;
		found = false;

		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i + 1][j];
					interactionNum = newCheck.checkSpotValue(eventNumber);
					if (interactionNum == 1) {
						eventNumber = temp;
						displayGrid();
						askMove();
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i + 1][j] = playerID;
						found = true;
						displayGrid();
						askMove();
					}
				}
			}
		}
	}

	public void moveUp() {
		temp = eventNumber;
		found = false;

		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i - 1][j];
					interactionNum = newCheck.checkSpotValue(eventNumber);
					if (interactionNum == 1) {
						eventNumber = temp;
						displayGrid();
						askMove();
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i - 1][j] = playerID;
						found = true;
						displayGrid();
						askMove();
					}
				}
			}
		}
	}

	public void getInput() {
		newView.playerCommand();
		
		
	}
	
	
	public void askMove() {
		
		newView.updateTextArea("Where would you like to move?");


		int moveNum = 0;


			
		moveNum = newCheck.moveCheck(move);

		switch (moveNum) {

		case 1:
			moveLeft();

			break;

		case 2:
			moveRight();
			break;

		case 3:
			moveUp();
			break;

		case 4:
			moveDown();
			break;

		case 0:
			askMove();
			break;

		}

	}

}