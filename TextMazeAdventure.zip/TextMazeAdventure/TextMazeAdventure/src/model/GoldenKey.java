package model;

public class GoldenKey extends Object implements StandardObject {
String desc;
	public GoldenKey(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {
		desc = "A key that shimmers as if there was a beam of light penetrating the ceiling and bouncing off of it. What purpose could such a divine key have?";
		return null;
	}

	@Override
	public String Action() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String Loot() {
		// TODO Auto-generated method stub
		return null;
	}

}
