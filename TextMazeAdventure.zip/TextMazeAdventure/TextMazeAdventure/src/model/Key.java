package model;

public class Key extends Object implements StandardObject {

	String desc;

	public Key(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {
		desc = "A key lays before you on the ground, almost concealed by the dust, whats left of the shimmering bronze catches your eyes";

		return desc;
	}

	@Override
	public String Action() {
		desc = "Do you pick up the key?";
		return desc;

	}

	@Override
	public String Loot() {
		desc = "You have picked up a key, it looks rusted and worn, but perhaps still capable of opening something...";
		return desc;
		

	}

}
