package model;

public class Ground extends Object implements StandardObject {

	String desc;
	
	public Ground(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}



	@Override
	public String Description() {
		desc = "There is nothing here but the dusty and eroded ground"; 
		return desc;
	}

	@Override
	public String Action() {
		desc = "";
		return desc;
		// TODO Auto-generated method stub
		
	}

	@Override
	public String Loot() {
		return desc;
		// TODO Auto-generated method stub
		
	}
}