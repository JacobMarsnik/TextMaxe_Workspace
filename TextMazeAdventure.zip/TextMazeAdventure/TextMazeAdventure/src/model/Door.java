package model;

public class Door extends Object implements StandardObject {

	String desc;
	
	public Door(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {
		// TODO Auto-generated method stub
		desc = " A grandiose door stands in front of you, you can sense a draft coming from the cracks near it. " + "\n" + 
		" could this be your way out of this forsaken place?";
		
		
		return desc;
	}

	@Override
	public String Action() {
		desc = "Do you attempt to open the door?";
		return desc;
	}

	@Override
	public String Loot() {
		desc = "The stone door slowly opens, scraping the ground as it moves, revealing a breathtaking view...";
		return desc;
	}

}
