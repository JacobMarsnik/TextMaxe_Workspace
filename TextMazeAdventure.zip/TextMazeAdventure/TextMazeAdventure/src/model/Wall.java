package model;

public class Wall extends Object implements StandardObject {

	public Wall(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {
		String desc = "A wall covered in dust and moss, these walls have stood the test of time.";
		return desc;
	}

	@Override
	public String Action() {
		return null;
		// TODO Auto-generated method stub
		
	}

	@Override
	public String Loot() {
		return null;
		// TODO Auto-generated method stub
		
	}

}
