package main;

import controller.Controller;
import model.GameBoard;
import view.GameView;

public class TextMazeApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Controller controller = new Controller();
}
}