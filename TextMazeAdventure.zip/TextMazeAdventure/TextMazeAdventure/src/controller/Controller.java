package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.io.*;

import model.GameBoard;
import view.GameView;

public class Controller {
	private GameBoard model;
	private int inputNum = 999;
	private String[] showOutput = new String[2];
	private String action;

	GameView newView = new GameView();
	GameBoard newModel = new GameBoard();

	public Controller() {

		ActionListener listen = new EnterKeyHandler();

		newView.playerCommand().addActionListener(listen);

		

		newView.updateTextArea("Welcome to the Maze ");
		newView.updateTextArea("Please type 'Start' and hit enter to begin.");

	}

	public void addModel(GameBoard m) {
		this.model = m;
	}

	public void checkInput() {

		String newInput = newView.playerCommand().getText();
		switch (inputNum) {
		case 0:
			move(newInput);
			break;
		case 1:
			ynFunction(newInput);
			break;
		case 999:
		boolean start =	newModel.checkStart(newInput);
		if(start) {
			newModel.startMaze();
			newView.clearTextArea();
			askMove();
		}
		else {
			newView.updateTextArea("Please enter 'Start' to begin");
		}
			break;

		default:
			newView.updateTextArea("Please enter a valid instruction" + "\n");
		}
	}

	private void move(String s) {

		switch (s.toLowerCase()) {
		case "right":
			showOutput = newModel.moveRight();

			newView.updateTextArea(showOutput[0] );

			if (showOutput[1] != "" && !showOutput[1].isEmpty() && showOutput[1] != null) {
				newView.updateTextArea("\n" + showOutput[1] + "\n");
				//newView.updateTextArea("There was an action");
				inputNum = 1;
			} else {
				askMove();
			}

			break;
		case "left":
			showOutput = newModel.moveLeft();

			newView.updateTextArea(showOutput[0] );

			if (showOutput[1] != "" && !showOutput[1].isEmpty() && showOutput[1] != null) {
				newView.updateTextArea("\n" + showOutput[1] + "\n");
		//		newView.updateTextArea("There was an action");
				inputNum = 1;
			} else {
				askMove();
			}

			break;
		case "down":
			showOutput = newModel.moveDown();

			newView.updateTextArea(showOutput[0] );

			if (showOutput[1] != "" && !showOutput[1].isEmpty() && showOutput[1] != null) {
				newView.updateTextArea("\n" + showOutput[1] + "\n");
			//	newView.updateTextArea("There was an action");
				inputNum = 1;
			} else {
				askMove();
			}

			break;
		case "up":
			showOutput = newModel.moveUp();

			newView.updateTextArea(showOutput[0] );

			if (showOutput[1] != "" && !showOutput[1].isEmpty() && showOutput[1] != null) {
				newView.updateTextArea( "\n" + showOutput[1] + "\n");
				//newView.updateTextArea("There was an action");
				inputNum = 1;
			} else {
				askMove();
			}

			break;
		default:
			newView.updateTextArea("Please Enter in a valid command" + "\n");
		}

	}

	public void askMove() {
		newView.updateTextArea(  "\n" +"Where would you like to move" + "\n");
		inputNum = 0;

	}

	public int changeInputNum(int x) {

		int newInput = x;
		return newInput;

	}

	public void ynFunction(String newInput) {
		// TODO Auto-generated method stub
		if (newInput.toLowerCase().equals("yes")) {
			//newView.updateTextArea("Action Succesful");
			String actionOutput = newModel.doAction();
			newView.updateTextArea(actionOutput);
			inputNum = 0;
		} else if (newInput.toLowerCase().equals("no")) {
			//newView.updateTextArea("Action not Succesful");
			inputNum = 0;
		} else {
			newView.updateTextArea("Hmmm that dosnt seem right");

		}
		

	}

	private class EnterKeyHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// newView.updateTextArea("\n" + "text");
			checkInput();
			newView.playerCommand().setText("");

		}

	}

}
