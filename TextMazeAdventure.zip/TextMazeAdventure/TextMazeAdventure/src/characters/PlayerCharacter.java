package characters;

import java.util.ArrayList;
import java.util.List;

public class PlayerCharacter {

	private String name;
	private int health;
	boolean newBool;
	final private int size;
	private int attack;
	
	List<Object> inventory = new ArrayList<Object>();
	public PlayerCharacter(String n, int h, int s, int a) {
		name = n;
		health = h;
		size = s;
		attack = a;
		
		

	}

	public int changeHealth(int c) {
		int newHealth = health - c;
		health = newHealth;
		return health;
	}

	public void addToInventory(Object newObject) {

		inventory.add(newObject);
		
		
	}

	
	public boolean findKey(String k) {
		
		for (Object object: inventory) {
			String objectName = object.getClass().getName();
//			if(object.getClass().getName()== "model.Key") {
			if (objectName.equals(k)) {
				newBool = true;
			}
			else {
				newBool =  false;
			}
		}
		return newBool;
	}
	
//public boolean findGoldenKey() {
//		
//		for (Object object: inventory) {
//			String objectName = object.getClass().getName();
////			if(object.getClass().getName()== "model.Key") {
//			if (objectName.equals("model.Golden Key")) {
//				newBool = true;
//			}
//			else {
//				newBool =  false;
//			}
//		}
//		return newBool;
//	}
	
	
	
	
	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	

	public List<Object> getInventory() {
		return inventory;
	}

	public void setInventory(List<Object> inventory) {
		this.inventory = inventory;
	}

	public int getSize() {
		return size;
	}

}
