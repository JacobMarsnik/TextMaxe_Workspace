package view;

import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class EndView extends JFrame {
	
	private static int WIDTH = 400;
	private static int HEIGHT = 400;

	
	

	private JLabel congratulations;
	
	
	
	
	
	public EndView() {
		setTitle("Help and Information");
		setSize(WIDTH, HEIGHT);

		congratulations = new JLabel("Basic Inputs");
		
		congratulations.setFont(congratulations.getFont().deriveFont(20));
		
		
		
		
		Container pane = getContentPane();
		pane.setLayout(null);
		
		
		
		
		
		congratulations.setLocation(50,15);
		congratulations.setSize(900,200);
		
		
		
		pane.add(congratulations);
		
		
		congratulations.setText("CONGRATULATIONS YOU'VE MADE IT OUT");
		
		
		
		setVisible(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
	}
}
