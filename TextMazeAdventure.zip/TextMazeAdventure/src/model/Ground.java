package model;

public class Ground extends Object implements StandardObject {

	String desc;
	
	public Ground(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}



	@Override
	public String Description() {
		desc = "\n" + "There is nothing here but the dusty and eroded ground." + "\n" + " No point in staying here." ; 
		return desc;
	}

	@Override
	public String Action() {
		desc = "";
		return desc;
		// TODO Auto-generated method stub
		
	}

	@Override
	public String Loot() {
		return desc;
		// TODO Auto-generated method stub
		
	}
}