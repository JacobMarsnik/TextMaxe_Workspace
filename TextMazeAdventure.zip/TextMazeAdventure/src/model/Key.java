package model;

public class Key extends Object implements StandardObject {

	public Key(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {
		String desc = "A key lays before you on the ground, almost concealed by the dust, whats left of the shimmering bronze catches your eyes";
		
		return desc;
	}

	@Override
	public void Action() {
		String actionDesc = "Would you like to pick up the key?";
		String  awnser = input.nextLine();
		if(awnser.toLowerCase().equals("yes")) {
			Loot();
		}else if(awnser.toLowerCase().equals("no")) {
			return;
		}
		else {
			//append message here
			return;
		}
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Loot() {
		
		
	}

}
