package model;
import java.util.concurrent.ThreadLocalRandom;
public class Trap extends Object implements StandardObject {

	String desc;
	int min = 0;
	int max = 10;
	
	public Trap(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {
		desc = "There seems to be something off about the floor in this area, you arent sure what it is.";
		return desc;
	}

	@Override
	public String Action() {
		desc = "Do you investigate the suspicious area?" + "\n" + "Or do you continue and ignore it";

		return desc;
	}

	@Override
	public String Loot() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public int getRandomNum() {
		int randomNum = ThreadLocalRandom.current().nextInt(min, max + 1);
		return randomNum;
	}

	public String success() {
		desc = "You manage to dodge the darts that come out of floor, that was a close one" + "\n";
		return desc;
	}
	
	public String fail() {
		desc = "You got hit by darts" + "\n";
		return desc;
	}
	
	
	
}
