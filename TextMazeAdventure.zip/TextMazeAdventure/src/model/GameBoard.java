package model;

import characters.PlayerCharacter;
import model.Chest;
import model.Key;
import model.Wall;

public class GameBoard {

	PlayerCharacter player = new PlayerCharacter("Donovan", 50, 10, 5);

	private String move;
	int inputNum = 0;
	private int temp;
	private int interactionNum;
	private int SPX = 1;
	private int SPY = 1;
	private int playerID = 99;
	private int eventNumber;
	private int PPX;
	private int PPY;
	private String output;
	private boolean found;

	int[][] mazeArray = new int[][]

	{ { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, { 1, 0, 2, 9, 0, 3, 0, 1, 0, 0, 8, 1 },
			{ 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 }, { 1, 0, 2, 0, 6, 0, 0, 1, 7, 0, 0, 1 },
			{ 1, 4, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 }, { 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
			{ 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 9, 1 }, { 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
			{ 1, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 1 }, { 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 9, 1 },
			{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };

	public void startMaze() {
		eventNumber = mazeArray[SPX][SPY]; // set the original event number to the starting spots value
		mazeArray[SPX][SPY] = playerID; // set the player to beginning spot
		PPX = SPX;
		PPY = SPY;

	}

	public String moveLeft() {
		temp = eventNumber;
		found = false;
		String showInfo = "Nothing";
		for (int i = 0; found == false && i < mazeArray.length; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i][j - 1];
					showInfo = checkSpotValue(eventNumber);
					if (eventNumber == 1) {
						eventNumber = temp;
						return showInfo;

					} else {
						mazeArray[i][j] = temp;
						mazeArray[i][j - 1] = playerID;
						found = true;
					}
				}
			}
		}
		return showInfo;
	}

	public String moveRight() {
		temp = eventNumber;
		found = false;
		String showInfo = "Nothing";
		for (int i = 0; !found && i < mazeArray.length; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i][j + 1];
					showInfo = checkSpotValue(eventNumber);
					if (eventNumber == 1) {
						eventNumber = temp;
						return showInfo;
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i][j + 1] = playerID;
						found = true;

					}
				}
			}
		}
		return showInfo;
	}

	public String moveDown() {
		temp = eventNumber;
		found = false;
		String showInfo = "Nothing";

		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i + 1][j];
					showInfo = checkSpotValue(eventNumber);
					if (eventNumber == 1) {
						eventNumber = temp;
						return showInfo;
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i + 1][j] = playerID;
						found = true;

					}
				}
			}
		}
		return showInfo;
	}

	public String moveUp() {
		temp = eventNumber;
		found = false;
		String showInfo = "Nothing";

		for (int i = 0; found == false; i++) {
			for (int j = 0; found == false && j < mazeArray.length; j++) {
				if (mazeArray[i][j] == playerID) {
					eventNumber = mazeArray[i - 1][j];
					showInfo = checkSpotValue(eventNumber);
					if (eventNumber == 1) {
						eventNumber = temp;
						return showInfo;
					} else {
						mazeArray[i][j] = temp;
						mazeArray[i - 1][j] = playerID;
						found = true;

					}
				}
			}
		}
		return showInfo;
	}

	public String checkSpotValue(int x) {

		switch (x) {
		case 0:
			x = 0;
			Ground ground = new Ground("Tiles");
			output = ground.Description();
			break;

		case 1:
			x = 1;

			Wall wall = new Wall("Wall");
			output = wall.Description();
//					
			break;

		case 2:
			x = 2;
			Chest chest = new Chest("Chest");
			output = chest.Description();
			break;

		case 3:
			x = 3;
			break;

		case 4:
			x = 4;
			break;

		case 5:
			x = 5;
			break;
		case 6:
			x = 6;
			break;
		case 7:
			x = 7;
			break;
		case 8:
			x = 8;
			break;
		case 9:
			x = 9;
			Key key = new Key("Shiny Key");
			 output = key.Description();
			break;
		}

		return output;

	}

	public int getTemp() {
		return temp;
	}

	public void setTemp(int temp) {
		this.temp = temp;
	}

	public int getInteractionNum() {
		return interactionNum;
	}

	public void setInteractionNum(int interactionNum) {
		this.interactionNum = interactionNum;
	}

	public int getSPX() {
		return SPX;
	}

	public void setSPX(int sPX) {
		SPX = sPX;
	}

	public int getSPY() {
		return SPY;
	}

	public void setSPY(int sPY) {
		SPY = sPY;
	}

	public int getPlayerID() {
		return playerID;
	}

	public void setPlayerID(int playerID) {
		this.playerID = playerID;
	}

	public int getEventNumber() {
		return eventNumber;
	}

	public void setEventNumber(int eventNumber) {
		this.eventNumber = eventNumber;
	}

	public int getPPX() {
		return PPX;
	}

	public void setPPX(int pPX) {
		PPX = pPX;
	}

	public int getPPY() {
		return PPY;
	}

	public void setPPY(int pPY) {
		PPY = pPY;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}

	public boolean isFound() {
		return found;
	}

	public void setFound(boolean found) {
		this.found = found;
	}

	public PlayerCharacter getPlayer() {
		return player;
	}

	public void setPlayer(PlayerCharacter player) {
		this.player = player;
	}

	public String getMove() {
		return move;
	}

	public void setMove(String move) {
		this.move = move;
	}

	public int[][] getMazeArray() {
		return mazeArray;
	}

	public void setMazeArray(int[][] mazeArray) {
		this.mazeArray = mazeArray;
	}

	public void CheckInputNum() {
		// TODO Auto-generated method stub

	}

}
