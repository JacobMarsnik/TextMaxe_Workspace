package model;

import java.util.Scanner;



public interface StandardObject {
	
	public String Description();
	public String Action();
	public void Loot();

}
