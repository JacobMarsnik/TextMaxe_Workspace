package model;

import java.util.Scanner;



public interface StandardObject {
	
	public String Description();
	public void Action();
	public void Loot();

}
