package model;

import java.util.Scanner;

public class Chest extends Object implements StandardObject {

	String desc;
	boolean open = false;
	

	public Chest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {

		desc = "Before you sits an aincent wooden chest. The lock seems to be rusted, you might be able to open it and see what is inside";		
		return desc;
	}

	@Override
	public void Action() {



	}

	@Override
	public void Loot() {
		// TODO Auto-generated method stub
		System.out.println("It seems to be empty, an unfortunate turn of events.");

	}

}
