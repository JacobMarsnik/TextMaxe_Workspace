package model;

import java.util.Scanner;

public class Chest extends Object implements StandardObject {

	String desc;
	boolean open = false;
	boolean found = false;
	int lootCounter = 0;
	

	public Chest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String Description() {

		desc = "Before you sits an aincent wooden chest. The lock seems to be rusted, you might be able to open it and see what is inside";		
		return desc;
	}

	@Override
	public String Action() {

		desc =  "Do you attempt to open the chest?";		
		return desc;

	}

	@Override
	public String Loot() {
		
		if(lootCounter < 3) {
		desc = ("It seems to be empty, an unfortunate turn of events." +"\n" + "The chest crumbles into dust, unable to keep its form any longer.");
		
		lootCounter ++;
		}
		else if(lootCounter == 3) {
			desc = "You find a golden key, looks different then the rusted key you used, perhaps this is the key to your escape...";
		}
		else {
			desc = "Something has gone wrong";
		}
		
		
		
return desc;
	}
	
	public boolean haveGoldKey() {
		if (lootCounter  == 3){
			found = true;
		}
		else {
			found = false;
		}
		
		return found;
		
	}
	
	
	

}
