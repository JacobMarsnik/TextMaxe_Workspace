package view;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.*;

import model.GameBoard;




public class GameView extends JFrame implements ItemListener, ActionListener{

	
	private GameBoard model;
	
	private static int WIDTH = 1000;
	private static int HEIGHT = 1000;

	
	
	private JButton startGame, help;
	private JLabel playerName, display2;
	private JTextField input;
	private JTextArea display;
	
	
	
	
	public GameView() {
		setTitle("Text Maze Adventure");
		setSize(WIDTH, HEIGHT);
	JScrollPane scroll = new JScrollPane(display);
		input = new JTextField(null);
		startGame = new JButton("Start New Game");
		help = new JButton("Help");
		
		display2 = new JLabel("");
		
		playerName = new JLabel("PlayerName");
		
		display = new JTextArea(6,30);
		
		
		Container pane = getContentPane();
		pane.setLayout(null);
		
		display.setEditable ( false );
		
		input.setLocation(400,750);
		input.setSize(250,50);
		input.setFocusable(true);
	
		startGame.setLocation(600,120);
		startGame.setSize(100,35);
		
		help.setLocation(250,120);
		help.setSize(100,35);
		
		playerName.setLocation(250,150);
		playerName.setSize(200,35);
		
		display.setLocation(250,200);
		display.setSize(450, 500);
		display.setEditable(false);
		display.setLineWrap(true);
		
		
		pane.add(display);
		pane.add(startGame);
		pane.add(help);
		pane.add(playerName);
		pane.add(input);
		pane.add(scroll);
		
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
//		input.addActionListener(this);
		
	}
	
	
	
	public void addController( ActionListener controller) {
		input.addActionListener(controller);
		
	}
	


	public void addGameModel(GameBoard model) {
		
	}
	
	
	@Override
	public void itemStateChanged(ItemEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	public void updateTextArea(String e) {
		display.append(e + " \n");
	}
	
	public JTextField playerCommand() {
		
		return input;
		
	}
	









	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
