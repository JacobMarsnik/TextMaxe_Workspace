package view;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.*;

import model.GameBoard;




public class GameView extends JFrame implements ItemListener, ActionListener{

	
	private GameBoard model;
	Helpview helpView = new Helpview();
	
	
	private static int WIDTH = 1000;
	private static int HEIGHT = 1000;

	
	
	private JButton startGame, help, clear;
	private JLabel playerName, health;
	private JTextField input;
	private JTextArea display;
	
	
	
	
	public GameView() {
		setTitle("Text Maze Adventure");
		setSize(WIDTH, HEIGHT);
	JScrollPane scroll = new JScrollPane(display);
		input = new JTextField(null); 
		
		JButton help = new JButton( new AbstractAction("Help")  {
			@Override
			public void actionPerformed (ActionEvent e) {
				helpView.setVisible(true);
				
			}
		});
		
		
				
		clear = new JButton("Clear");
		health = new JLabel("health");
		
		
		playerName = new JLabel("PlayerName");
		
		display = new JTextArea(6,30);
		
		
		Container pane = getContentPane();
		pane.setLayout(null);
		
		display.setEditable ( false );
		
		clear.setLocation(290, 750);
		clear.setSize(100,35);
		
		input.setLocation(400,750);
		input.setSize(250,50);
		input.setFocusable(true);
	
		health.setLocation(400,150);
		health.setSize(100,35);
		
		help.setLocation(660,750);
		help.setSize(100,35);
		
		playerName.setLocation(170,150);
		playerName.setSize(200,35);
		
		display.setLocation(160,200);
		display.setSize(700, 500);
		display.setEditable(false);
		display.setLineWrap(true);
		
		pane.add(clear);
		pane.add(display);
		pane.add(health);
		pane.add(help);
		pane.add(playerName);
		pane.add(input);
		
		pane.add(scroll);
		
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		clear.addActionListener(this);
//		input.addActionListener(this);
		help.addActionListener(this);
		
	}
	
	
	
	
	public void addController( ActionListener controller) {
		input.addActionListener(controller);
		
	}
	


	public void addGameModel(GameBoard model) {
		
	}
	
	
	@Override
	public void itemStateChanged(ItemEvent arg0) {
	 display.setText(null);
		
	}
	public void updateTextArea(String e) {
		display.append(e + " \n");
	}
	
	
	public void clearTextArea() {
		display.setText("");
	}
	public JTextField playerCommand() {
		
		return input;
		
	}
	

public void setName(String s) {
	playerName.setText("Name: " + s);
}

public void setHealth(int i) {
	health.setText("Health: " + Integer.toString(i) );
}





	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	display.setText("");
		
	}

}
