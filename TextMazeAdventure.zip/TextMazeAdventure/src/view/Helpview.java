package view;

import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Helpview extends JFrame {
	
	private static int WIDTH = 400;
	private static int HEIGHT = 400;

	
	

	private JLabel information;
	private JTextArea displayHelp;
	
	
	
	
	public Helpview() {
		setTitle("Help and Information");
		setSize(WIDTH, HEIGHT);

		information = new JLabel("Basic Inputs");
		
		//playerName = new JLabel("PlayerName");
		
		displayHelp = new JTextArea(6,30);
		
		
		Container pane = getContentPane();
		pane.setLayout(null);
		
		displayHelp.setEditable ( false );
		
		
		
		information.setLocation(150,15);
		information.setSize(200,35);
		
		displayHelp.setLocation(50,50);
		displayHelp.setSize(300, 300);
		displayHelp.setEditable(false);
		displayHelp.setLineWrap(true);
		
		pane.add(information);
		pane.add(displayHelp);
		
		displayHelp.setText("Movement: 'Right', 'Left', 'Up' or 'Down'" + "\n" + "\n" +
		                     "If presented with a choice: 'Yes', 'No', 'Investigate' or        'Continue' " 
				+ "\n" + "\n" +"\n" + "How To Win: Find you way out of the maze using" + "\n" + "whatever you find along the way");
		
		
		
		setVisible(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
	}
}
